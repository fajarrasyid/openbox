rofi -no-lazy-grab -show run -theme themes/runcommand.rasi
